# Alex Hunt & Thi Thuy Trang Tran
# Group 2
# Professor Habibi
# Project 2 : Adversarial Search
# 2/17/23

# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

from util import manhattanDistance
from game import Directions
import random, util
from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.
    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """
    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.
        getAction chooses among the best options according to the evaluation function.
        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action): # Q1
        """
        Design a better evaluation function here.
        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.
        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.
        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        currentFoodList = currentGameState.getFood().asList()   #list of current food position
        pacToFood = []                                          #list of manhattan distances from pacman's next position to food
        for food in currentFoodList:
            pacToFood.append(manhattanDistance(newPos, food))
        
        newGhostPos = successorGameState.getGhostPositions()    #list of ghost postion
        
        for ghost in newGhostPos:                               
            if ghost == newPos:                                
                return float("-inf")       #the evaluation number will be super small so pacman wont choose it
        
        #avoid STOP action which reduce Pacman score
        if Directions.STOP in action:                           
            return float("-inf")   # negative infinity
        if len(currentFoodList) != 0:
            distance = min(pacToFood)      #closest food
            return 1.0/(1.0 + distance)    #to avoid divide by zero error
        
def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI
    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.
    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.
    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """
    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent): #Q2
    """
    Your minimax agent (question 2)
    """
    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.
          Here are some method calls that might be useful when implementing minimax.
          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1
          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action
          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        return self.value(gameState, self.index,0)[1]       

    def value(self, gameState, agentIndex, nodeDepth):
        #check if a node is a terminal node, or the game is over, and returns the evaluation value of that node
        if nodeDepth == self.depth or gameState.isWin() or gameState.isLose():   
            return(self.evaluationFunction(gameState), "none")
        
        #check if agent is Pacman or ghosts to call approriate function
        if agentIndex == 0:
            return self.max_value(gameState, agentIndex, nodeDepth)
        else:
            return self.min_value(gameState, agentIndex, nodeDepth)
    
    #used for the Pacman to find the action with the maximum evaluation value.
    def max_value(self, gameState, agentIndex, nodeDepth):        
        v = float("-inf")
        actionList = gameState.getLegalActions(self.index)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            temp = self.value(successor, agentIndex + 1, nodeDepth)[0]  
            if temp > v:   #find the maximum value and return the coresponding action
                v = temp
                a = action
        return (v,a)
    
    #for the ghosts, finding the action with the minimum evaluation value  
    def min_value(self, gameState, agentIndex, nodeDepth):      
        v = float("inf")
        actionList = gameState.getLegalActions(agentIndex)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            #check if current agent is the last agent so the next agent must be the pacman in the next depth    
            #if it is not the last one, then move to the next agent in the same depth     
            if agentIndex==gameState.getNumAgents() - 1:        
                temp = self.value(successor, 0, nodeDepth + 1)[0]
            else:
                temp = self.value(successor, agentIndex+1, nodeDepth)[0]  
            #find the min value and the coresponding action
            if temp < v:  
                v = temp
                a = action
        return (v,a)
    
class AlphaBetaAgent(MultiAgentSearchAgent): #Q3
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        alpha = float("-inf")          #MAX's best option on path to root
        beta = float("inf")            #MIN's best option on path to root
        return self.value(gameState, self.index, 0, alpha, beta)[1]
    def value(self, gameState, agentIndex, nodeDepth, alpha, beta):
        if nodeDepth == self.depth or gameState.isWin() or gameState.isLose():
            return(self.evaluationFunction(gameState), "none")
        if agentIndex == 0:
            return self.max_value(gameState, agentIndex, nodeDepth, alpha, beta)
        else:
            return self.min_value(gameState, agentIndex, nodeDepth, alpha, beta)
    
    def max_value(self, gameState, agentIndex, nodeDepth, alpha, beta):
        v = float("-inf")
        actionList = gameState.getLegalActions(self.index)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            temp = self.value(successor, agentIndex + 1, nodeDepth, alpha, beta)[0]
            if temp > v:
                v = temp
                a = action
            if v > beta:             #check if the value of next agent > b, the current state will never be reached 
                return (v,a)         #because the pacman will never choose this action, so the algorithm can return v is negative infinitive
            alpha = max(alpha, v)    #keep track the alpha value
        return (v,a)
       
    def min_value(self, gameState, agentIndex, nodeDepth, alpha, beta):
        v = float("inf")
        actionList = gameState.getLegalActions(agentIndex)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            if agentIndex==gameState.getNumAgents() - 1:
                temp = self.value(successor, 0, nodeDepth + 1, alpha, beta)[0]
            else:
                temp = self.value(successor, agentIndex+1, nodeDepth, alpha, beta)[0]
            if temp < v:
                v = temp
                a = action
            if v < alpha:           #check if the value of next agent < a, the current state will always be reached 
                return (v,a)        #because the pacman will always choose this action, so the algorithm can return v is positive infinitive
            beta = min(beta, v)     #keep track the beta value
        return (v,a)
    
class ExpectimaxAgent(MultiAgentSearchAgent): #Q4
    """
      Your expectimax agent (question 4)
    """
    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        return self.value(gameState, self.index,0)[1]
    #Similar to minimaxAgent, but if agents are ghosts, we call exp_value() function instead of min_value()
    def value(self, gameState, agentIndex, nodeDepth):
        if nodeDepth == self.depth or gameState.isWin() or gameState.isLose():
            return(self.evaluationFunction(gameState),None)
        if agentIndex == 0:
            return self.max_value(gameState, agentIndex, nodeDepth)
        else:
            return self.exp_value(gameState, agentIndex, nodeDepth)
        
    #used for the Pacman to find the action with the maximum evaluation value.
    def max_value(self, gameState, agentIndex, nodeDepth):
        v = float("-inf")
        actionList = gameState.getLegalActions(self.index)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            temp = self.value(successor, agentIndex + 1, nodeDepth)[0]
            if temp > v:
                v = temp
                a = action
        return (v,a)
       
    def exp_value(self, gameState, agentIndex, nodeDepth):
        v = 0
        actionList = gameState.getLegalActions(agentIndex)
        for action in actionList:
            successor =  gameState.generateSuccessor(agentIndex, action)
            # check if current agent is the last agent so the next agent must be the pacman in the next depth    
            # if it is not the last one, then move to the next agent in the same depth    
            if agentIndex==gameState.getNumAgents() - 1:
                temp = self.value(successor, 0, nodeDepth + 1)[0]
            else:
                temp = self.value(successor, agentIndex+1, nodeDepth)[0]
            p = 1/len(actionList)   #probability of equally weighted action
            v += temp * p           #calculate the weighted value
        return (v, "none")

def betterEvaluationFunction(currentGameState): #Q5
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"

    currPos = currentGameState.getPacmanPosition()  # current position of pacman
    currSco = currentGameState.getScore()           # current score of state

    ghosPos = currentGameState.getGhostPositions()  # current positions of ghosts
    foodPos = currentGameState.getFood().asList()   # current positions of food
    foodAmt = len(foodPos)
    distanc = 1 

    pacToFood = []
    for food in foodPos:
        pacToFood.append(manhattanDistance(currPos, food)) # to find the closest food

    if len(foodPos) != 0:
        distanc = min(pacToFood)

    pacToGhosts = []
    for ghos in ghosPos:
        pacToGhos = manhattanDistance(currPos, ghos) # to find if there is a ghost within 2 squares, if so, make it expensive
        if pacToGhos < 2:
            distanc = 999
           
    capAmt = len(currentGameState.getCapsules())
    
    x = [1.0 / distanc, currSco, foodAmt, capAmt] # give certain imporance to certain characteristics of the state space
    y = [50, 200, -100, -10]
    xy = zip(x, y)
    cost = 0
    for feature, weight in xy:
        cost += feature*weight

    return cost

# Abbreviation
better = betterEvaluationFunction
